export const routes = {
    home: "/",
    settings: "/settings",
    info: "/info"
}